SOMMELIER — prima versione PWA + preparazione cloud

FUNZIONA ORA
- Interfaccia italiana responsive, stile bordeaux e oro.
- Inventario locale fino a 150 bottiglie.
- Inserimento dati e foto etichetta da fotocamera o libreria.
- Prezzo d'acquisto e valore totale.
- Scheda bottiglia e diario degustazioni con punteggio personale.
- Manifest PWA e service worker.

NON È ANCORA ATTIVO
- Pubblicazione HTTPS e installazione definitiva su iPhone.
- Account, login e sincronizzazione cloud.
- Riconoscimento AI delle etichette.
- Valutazioni di mercato e finestre di beva automatiche.

CLOUD
La cartella supabase contiene schema.sql per predisporre tabelle private, Row Level Security e bucket privato delle fotografie. Seguire CLOUD-SETUP-DA-IPHONE.txt. L'esecuzione dello schema NON collega da sola l'app al cloud: login e sincronizzazione devono ancora essere implementati e verificati.

ATTENZIONE AI DATI
Fino all'attivazione e verifica del cloud, i dati restano nel browser/dispositivo. Non cancellare i dati di Safari o del sito. Conservare una copia separata dell'inventario.


CLOUD COLLEGATO NEL CODICE (build 2)
- config.js contiene Project URL e Publishable key forniti dall'utente. La publishable key è pubblica e non equivale a una service_role/secret key.
- Login email/password e registrazione Supabase implementati.
- Lettura e scrittura delle tabelle public.wines e public.tastings con RLS.
- Il codice è allineato allo schema SQL creato nel progetto dell'utente (wine_name, purchase_price, tasting_date).
- Le foto sono ancora locali e non vengono caricate nel bucket. L'importazione automatica di vecchi dati locali non è implementata.
- Prima dell'uso reale pubblicare su hosting HTTPS, testare registrazione/login e inserimento/lettura cloud.
